﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication3.Model
{
    public class GetAgentList
    {
        public int usercode { get; set; }
        public string username { get; set; }
        public int parentid { get; set; }
        public string emailid { get; set; }
        public string mobile { get; set; }
        public string status { get; set; }
        public string bankname { get; set; }
        public string ifsccode { get; set; }
        public string accountno { get; set; }
        public string createddate { get; set; }


    }
}
