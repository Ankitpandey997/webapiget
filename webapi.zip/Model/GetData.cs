﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication3.Model
{
    public class GetData
    {
        public int transactionid { get; set; }
        public int serviceid { get; set; }
        public DateTime txndatetime { get; set; }
        public int txnamount { get; set; }
        public string status { get; set; }
        public int txnfee { get; set; }
        public string description { get; set; }

    }


}