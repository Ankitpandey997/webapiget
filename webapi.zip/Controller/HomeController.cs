﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using WebApplication3.Model;
using Newtonsoft.Json;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using BAL;
using Newtonsoft.Json.Linq;

namespace WebApplication3.Controller
{
    public class HomeController : ApiController
    {

        [HttpGet]

        [ActionName("Get")]
        public DataTable Get()
        {
            clsUser objGet = new clsUser();
            DataTable message = objGet.Get();
            return message;

        }

        [HttpGet]
        [ActionName("GetAgentList")]
        public DataTable GetAgentList()
        {
            clsUser objGet = new clsUser();
            DataTable message = objGet.GetAgentList();
            return message;

        }

        [HttpGet]
        [ActionName("PostDs")]
        public DataTable PostDs()
        {
            clsUser objGet = new clsUser();
            DataTable message = objGet.PostDs();
            return message;
        }
    }
}
      

